package com.arox.launcher

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.widget.*

class MainActivity : Activity() {
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("arox", MODE_PRIVATE)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(32), dp(32), dp(32), dp(32))
            background = GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(0xFF1A1A1A.toInt(), 0xFF2B2B2B.toInt())
            )
        }

        val icon = ImageView(this).apply {
            setImageResource(R.drawable.ic_a)
            layoutParams = LinearLayout.LayoutParams(dp(72), dp(72))
        }
        val title = TextView(this).apply {
            text = "AROX"
            textSize = 34f
            letterSpacing = 0.4f
            setTextColor(0xFFE8E8E8.toInt())
            typeface = Typeface.create("sans-serif-light", Typeface.NORMAL)
            gravity = Gravity.CENTER
            setPadding(0, dp(16), 0, 0)
        }
        val sub = TextView(this).apply {
            text = "CLIENT FOR MINECRAFT BEDROCK"
            textSize = 11f
            letterSpacing = 0.2f
            setTextColor(0xFF9A9A9A.toInt())
            gravity = Gravity.CENTER
            setPadding(0, dp(4), 0, dp(32))
        }
        val login = EditText(this).apply {
            hint = "Логин"
            setText(prefs.getString("login", ""))
            setHintTextColor(0xFF777777.toInt())
            setTextColor(0xFFE8E8E8.toInt())
            inputType = InputType.TYPE_CLASS_TEXT
            setSingleLine()
            setPadding(dp(18), dp(12), dp(18), dp(12))
            background = GradientDrawable().apply {
                cornerRadius = dp(14).toFloat()
                setColor(0x66000000)
                setStroke(dp(1), 0xFF3C3C3C.toInt())
            }
            layoutParams = LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { bottomMargin = dp(16) }
        }
        val start = Button(this).apply {
            text = "START"
            letterSpacing = 0.3f
            setTextColor(0xFF1A1A1A.toInt())
            background = GradientDrawable().apply {
                cornerRadius = dp(28).toFloat()
                setColor(0xFFE8E8E8.toInt())
            }
            elevation = dp(8).toFloat()
            layoutParams = LinearLayout.LayoutParams(MATCH_PARENT, dp(56))
            setOnClickListener {
                prefs.edit().putString("login", login.text.toString()).apply()
                launchMinecraft()
            }
        }

        root.addView(icon); root.addView(title); root.addView(sub)
        root.addView(login); root.addView(start)
        setContentView(root)
    }

    private fun launchMinecraft() {
        val intent = packageManager.getLaunchIntentForPackage("com.mojang.minecraftpe")
        if (intent != null) {
            startActivity(intent)
        } else {
            Toast.makeText(this, "Minecraft не установлен", Toast.LENGTH_LONG).show()
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=com.mojang.minecraftpe")))
        }
    }
}
